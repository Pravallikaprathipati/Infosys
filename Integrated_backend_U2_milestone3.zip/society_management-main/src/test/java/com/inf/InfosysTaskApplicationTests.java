package com.inf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfosysTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
