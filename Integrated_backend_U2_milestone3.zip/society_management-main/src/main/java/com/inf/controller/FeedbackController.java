package com.inf.controller;

import com.inf.dto.FeedbackAddreq;
import com.inf.service.FeedbackService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/feedback")
public class FeedbackController {

    private final FeedbackService feedbackService;
    @PostMapping("/add/event/{eventId}")
    public ResponseEntity<?> addFeedback(@PathVariable Long eventId, @RequestBody FeedbackAddreq feedbackAddreq) {
        return feedbackService.addFeedback(eventId, feedbackAddreq);

    }
    @PatchMapping("/{fbid}/update")
    public ResponseEntity<?> updateFeedback(@PathVariable Long fbid, @RequestBody Map<String,Object> updates) {
        return feedbackService.updateFeedback(fbid, updates);
    }

    @DeleteMapping("/{fbid}/delete")
    public ResponseEntity<?> deleteFeedback(@PathVariable Long fbid) {
        return feedbackService.deleteByfbid(fbid);
    }
    @GetMapping
    public ResponseEntity<?> getfeedbacks(){
        return feedbackService.getAllFeedback();

    }
}
