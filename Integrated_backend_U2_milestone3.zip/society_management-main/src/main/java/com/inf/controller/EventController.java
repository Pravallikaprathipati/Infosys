package com.inf.controller;

import com.inf.dto.EventAddResponse;
import com.inf.dto.EventaddRequest;
import com.inf.service.EventService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
@RequiredArgsConstructor
@RequestMapping("/events")
public class EventController {
    private final EventService eventService;

    @PostMapping("/add/society/{societyId}")
    public ResponseEntity<?> addEvent(@PathVariable long societyId, @RequestBody EventaddRequest eventaddRequest) {
        return eventService.addEvent(societyId, eventaddRequest);


    }
    @GetMapping()
    public List<EventAddResponse> getALlEvents(){
        return eventService.getAllEvents();
    }

    @PatchMapping("/{eventId}/update")
    public  ResponseEntity<?> updateEventById(@PathVariable Long eventId,@RequestBody Map<String,Object> updates){
        return eventService.updateEvent(eventId, updates);
    }

    @DeleteMapping("/{eventId}/delete")
    public ResponseEntity<?> deleteEventById(@PathVariable Long eventId){
        return eventService.deleteEvent(eventId);
    }
}
