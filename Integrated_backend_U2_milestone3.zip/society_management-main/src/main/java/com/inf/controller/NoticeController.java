package com.inf.controller;

import com.inf.dto.NoticeAddreq;

import com.inf.dto.NoticeResponse;
import com.inf.service.NoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/notices")
public class NoticeController {
    private final NoticeService noticeService;

    @PostMapping("/add/society/{societyId}")
    public ResponseEntity<?> AddNotice(@PathVariable Long societyId, @RequestBody NoticeAddreq noticeadd) {
        return noticeService.AddNotice(societyId, noticeadd);

    }

    @DeleteMapping("/{noticeId}/delete")
    public ResponseEntity<?> DeleteNotice(@PathVariable Long noticeId) {
        return noticeService.DeleteNotice(noticeId);
    }

    @GetMapping("/{noticeId}")
    public ResponseEntity<?> GetNotice(@PathVariable Long noticeId) {
        return noticeService.getNoticeById(noticeId);
    }
    @GetMapping
    public ResponseEntity<?> GetAllNotices(){
        return noticeService.GetAllNotices();

    }
    @PostMapping("/{noticeId}/update")
    public ResponseEntity<?> UpdateNotice(@PathVariable Long noticeId, @RequestBody NoticeResponse noticeupd){
        return noticeService.UpdateNotice(noticeId,noticeupd);
    }
    @PatchMapping("/{noticeId}/update")
    public ResponseEntity<?> PatchupdateNotice(@PathVariable Long noticeId,@RequestBody Map<String,Object> updates){
        return noticeService.PatchupdateNotice(noticeId,updates);

    }

}
