package com.inf.controller;

import com.inf.dto.SocietyDetailResponse;
import com.inf.dto.SocietyProfiledto;
import com.inf.service.SocietyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/societies")
public class SocietyController {

    @Autowired
    private SocietyService societyService;

    // Create

    // Read All
    @GetMapping
    public ResponseEntity<?> getAllSocieties() {
        return ResponseEntity.ok(societyService.getAllsocietyDetails());
    }

    // Read by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getSocietyById(@PathVariable Long id) {
        return societyService.getSocietyById(id);
    }

    // Update
    @PutMapping("/{id}")
    public ResponseEntity<?> updateSociety(@PathVariable Long id, @RequestBody SocietyDetailResponse societyDto) {
        return societyService.updateSociety(id, societyDto);
    }

    // Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteSociety(@PathVariable Long id) {

        return societyService.DeleteById(id);
    }
    @PatchMapping("/{id}")
    public  ResponseEntity<?> updateSociety(@PathVariable Long id,@RequestBody Map<String,Object> updates){
        return societyService.patchupdateSocietyById(id, updates);

    }
}
