package com.inf.controller;

import com.inf.dto.ResidentDetailResponse;

import com.inf.service.ResidentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/resident")
public class ResidentController {



    private final ResidentService residentService;



    @GetMapping("/residentsinfo")
    public List<ResidentDetailResponse> GetAllResident() {


        return residentService.getAllResidentDetails() ;
    }
    @PatchMapping("/{residentId}/update")
    public ResponseEntity<String> updatebyId(@PathVariable long residentId, @RequestBody Map<String,Object> updates){
        return residentService.updatebyId(residentId,updates);
    }

    @DeleteMapping("/{residentId}/delete")
    public ResponseEntity<String> deleteByID(@PathVariable long residentId){
        return residentService.deletbyId(residentId);

    }
}
