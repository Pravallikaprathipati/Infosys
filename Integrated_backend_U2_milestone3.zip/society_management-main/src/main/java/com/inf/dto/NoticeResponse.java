package com.inf.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NoticeResponse {
    private Long noticeId;
    private String heading;
    private String content;
    private String datePosted;
    private String noticeImage;
    private Long societyId;
}
