package com.inf.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EventAddResponse {
    private long eventId;
    private String eventName;
    private  String eventDate;
    private  String eventDetails;
    private String eventImage;
    private  long SocietyId;
}
