package com.inf.dto;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResidentProfileDTO {
    private String name;
    private String phoneNo;
    private String societyName;
    private String flatNo;
    private String postal;



}
