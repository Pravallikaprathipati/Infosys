package com.inf.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EventaddRequest {
    private String eventName;
    private   String eventDate;
    private  String eventDetails;
    private String eventImage;
}
