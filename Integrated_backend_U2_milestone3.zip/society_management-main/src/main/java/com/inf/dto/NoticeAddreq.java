package com.inf.dto;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NoticeAddreq {

    private String heading;
    private String content;
    private String noticeImage;


}
