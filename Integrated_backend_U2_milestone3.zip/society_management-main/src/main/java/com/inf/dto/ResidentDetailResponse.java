package com.inf.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ResidentDetailResponse {
    private long residentid;
    private String name;
    private String phoneNo;
    private String flatNo;
    private String postal;
    private String email;
    private long flatId;
    private long societyId;
    private long userId;
}
