package com.inf.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FeedbackReponse {
    private Long feedbackId;
    private String content;
    private Long eventId;
}
