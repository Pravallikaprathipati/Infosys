package com.inf.dto;

public class AdminProfileDTO {
    private String name;
    private String phoneNumber;
    private String societyName;
    private String societyAddress;
    private String city;
    private String district;
    private String postalCode;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getSocietyName() {
		return societyName;
	}
	public void setSocietyName(String societyName) {
		this.societyName = societyName;
	}
	public String getSocietyAddress() {
		return societyAddress;
	}
	public void setSocietyAddress(String societyAddress) {
		this.societyAddress = societyAddress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

    // Getters and setters...
}
