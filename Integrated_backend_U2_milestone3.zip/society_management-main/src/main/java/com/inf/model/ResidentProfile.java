package com.inf.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "resident_profiles")
public class ResidentProfile {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long residentid;
    private String name;
    private String phoneNo;
    private String flatNo;
    private String postal;
    private String email;
    @ManyToOne
    @JoinColumn(name = "society_id", nullable = false, referencedColumnName = "societyId")
    private SocietyProfile societyProfile;
    @OneToOne
    @JoinColumn(name = "flat_id", unique = true, referencedColumnName = "flatId")
    private Flat flat;

    private String Role;

    @OneToOne
    @JoinColumn(name = "user_id",nullable = false, referencedColumnName ="id" )
    private User user;
}