package com.inf.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Event {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

   private long eventId;
    private String eventName;
  private   String eventDate;
   private  String eventDetails;
   private String eventImage;
    @ManyToOne
    @JoinColumn(name="society_id",nullable = false,referencedColumnName ="societyId")
    private SocietyProfile society;




}
