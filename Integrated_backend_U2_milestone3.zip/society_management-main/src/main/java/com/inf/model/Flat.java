package com.inf.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Flat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long flatId;
    @Column(unique = true)
    private String flatNo;

    @ManyToOne
    @JoinColumn(name = "society_id",nullable = false,referencedColumnName = "societyId")
    private SocietyProfile societyProfile;

}
