package com.inf.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class Notice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long noticeId;
    private String heading;
    private String content;
    private String datePosted;
    private String noticeImage;

    @ManyToOne
    @JoinColumn(name = "society_id",nullable = false,referencedColumnName = "societyId")
    private SocietyProfile societyProfile;




}
