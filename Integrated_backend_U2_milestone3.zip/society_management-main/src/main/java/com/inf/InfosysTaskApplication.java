package com.inf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfosysTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfosysTaskApplication.class, args);
	}

}
