package com.inf.service;

import com.inf.dto.ResidentDetailResponse;
import com.inf.model.Flat;
import com.inf.model.ResidentProfile;
import com.inf.model.SocietyProfile;
import com.inf.model.User;
import com.inf.repository.FlatRepository;
import com.inf.repository.ResidentProfileRepository;
import com.inf.repository.SocietyRepo;
import com.inf.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ResidentService {
    private final ResidentProfileRepository residentProfileRepository;
    private final SocietyRepo societyRepo;
    private final FlatRepository flatRepository;
    private final UserRepository userRepository;

    public List<ResidentDetailResponse> getAllResidentDetails() {
        List<Object[]> results = residentProfileRepository.findAllResidentDetails();
        List<ResidentDetailResponse> responseList = new ArrayList<>();

        for (Object[] result : results) {
            ResidentDetailResponse response = new ResidentDetailResponse((Long) result[0], // residentId
                    (String) result[1], // name
                    (String) result[2], // phoneNo
                    (String) result[3], // flatNo
                    (String) result[4], // postal
                    (String) result[5], // email
                    (Long) result[6], // flatId
                    (Long) result[7],//societyId
                    (Long) result[8]// userId
            );
            responseList.add(response);
        }


        return responseList;
    }

    public ResponseEntity<String> updatebyId(long resId, Map<String, Object> updates) {
        Optional<ResidentProfile> optionalResident = residentProfileRepository.findById(resId);

        if (optionalResident.isPresent()) {


            ResidentProfile resident = optionalResident.get();


            // Apply updates to the resident object
            if (updates.containsKey("name")) {
                System.out.print(updates.get("name"));
                resident.setName((String) updates.get("name"));
            }
            if (updates.containsKey("phoneNo")) {
                resident.setPhoneNo((String) updates.get("phoneNo"));
            }

            if (updates.containsKey("flatNo")) {
                Flat existflat = resident.getFlat();
                Long fmaxId = flatRepository.findMaxFlatId();

                if (fmaxId == null) {
                    flatRepository.setAutoIncrement(1L);
                } else {
                    flatRepository.setAutoIncrement(fmaxId + 1);
                }

                if (existflat == null) {
                    Flat newflat = new Flat();
                    newflat.setFlatNo((String) updates.get("flatNo"));
                    newflat.setSocietyProfile(resident.getSocietyProfile());
                    flatRepository.save(newflat);
                    resident.setFlat(newflat);
                    resident.setFlatNo(newflat.getFlatNo());
                } else {
                    existflat.setFlatNo((String) updates.get("flatNo"));
                    flatRepository.save(existflat);
                    resident.setFlat(existflat);
                    resident.setFlatNo(existflat.getFlatNo());


                }


            }
            if (updates.containsKey("societyName")) {
                SocietyProfile society = societyRepo.findFirstBySocietyName((String) updates.get("societyName"));

                if (society == null) {
                    return ResponseEntity.status(HttpStatus.CONFLICT).body("Ask the Admin to Register the Society First");
                }
                resident.setSocietyProfile(society);
                resident.setPostal(society.getPostal());
                Flat fl = resident.getFlat();
                fl.setSocietyProfile(society);
                flatRepository.save(fl);


            }
            if (updates.containsKey("email") ) {
                System.out.println(updates.get("email"));

                Optional<User> userchk = userRepository.findById( resident.getUser().getId());

                if (userchk.isPresent()) {

                    User reghome = userchk.get();
                    resident.setEmail((String) updates.get("email"));
                    reghome.setUsername(resident.getEmail());
                    userRepository.save(reghome);
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("registered existing email Id not found");

                }

            }
            if (updates.containsKey("password")) {
                Optional<User> userchk = userRepository.findById( resident.getUser().getId());

                if (userchk.isPresent()) {
                    User reghome = userchk.get();
                    reghome.setPassword((String) updates.get("password"));
                    userRepository.save(reghome);
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("registered existing email Id not found");

                }
            }
            if (updates.containsKey("role")) {
                Optional<User> userchk = userRepository.findById( resident.getUser().getId());
                if (userchk.isPresent()) {
                    User reghome = userchk.get();
                    reghome.setRole((String) updates.get("role"));
                    userRepository.save(reghome);

                } else {

                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Existing Email Id not found for updating role");
                }
            }

            // Save the updated resident object back to the database
            residentProfileRepository.save(resident);
            return ResponseEntity.status(HttpStatus.OK).body("Resident updated Successfully");
        } else {
            // If the resident is not found, return null
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("resident Id Not found");
        }
    }

    public ResponseEntity<String> deletbyId(Long id) {
        Optional<ResidentProfile> res = residentProfileRepository.findById(id);
        if (res.isPresent()) {
            residentProfileRepository.delete(res.get());
            Flat f = res.get().getFlat();
            flatRepository.deleteById(f.getFlatId());
            Optional<User> regdl = userRepository.findByUsername(res.get().getEmail());
            if (regdl.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("registered existing email Id not found");
            }
            userRepository.delete(regdl.get());


            return ResponseEntity.status(HttpStatus.OK).body("Resident Deleted Successfully");

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("resident Id Not found");
        }


    }

}
