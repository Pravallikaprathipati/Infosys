package com.inf.service;
import com.inf.dto.NoticeAddreq;
import com.inf.dto.NoticeResponse;
import com.inf.model.Notice;
import com.inf.model.SocietyProfile;
import com.inf.repository.NoticeRepository;
import com.inf.repository.SocietyRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class NoticeService {
    private final NoticeRepository noticeRepository;
    private final SocietyRepo societyRepo;

    public ResponseEntity<?> AddNotice(Long societyId, NoticeAddreq noticeAddreq) {

        Optional<SocietyProfile> societyProfile = societyRepo.findById(societyId);
        if (societyProfile.isPresent()) {
            Long maxNid = noticeRepository.findMaxNoticeId();
            if (maxNid == null) {
                noticeRepository.setAutoIncrement(1L);
            } else {
                noticeRepository.setAutoIncrement(maxNid + 1L);
            }
            // Get current date and format it directly
            String curDate = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));

            //storing values in Notice Entity
            Notice notice = Notice.builder().heading(noticeAddreq.getHeading())
                    .content(noticeAddreq.getContent()).noticeImage(noticeAddreq.getNoticeImage())
                    .datePosted(curDate).societyProfile(societyProfile.get()).build();
            var saved = noticeRepository.save(notice);
            //creating noticeResponse for display the created and saved notice
            NoticeResponse noticeResponse = NoticeResponse.builder().noticeId(saved.getNoticeId())
                    .content(saved.getContent()).noticeImage(saved.getNoticeImage())
                    .datePosted(saved.getDatePosted()).heading(saved.getHeading()).societyId(saved.getSocietyProfile().getSocietyId()).build();

            return ResponseEntity.status(HttpStatus.CREATED).body(noticeResponse);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("SocietyId " + societyId + " is Not Found");
        }

    }

    public ResponseEntity<?> DeleteNotice(Long noticeId) {
        Optional<Notice> notice = noticeRepository.findById(noticeId);
        if (notice.isPresent()) {
            noticeRepository.deleteById(noticeId);
            return ResponseEntity.ok("NoticeId " + noticeId + " Deleted successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("NoticeId " + noticeId + " Not found");
        }

    }

    public ResponseEntity<?> getNoticeById(Long noticeId) {
        // Retrieve the Notice entity from the repository
        Optional<Notice> noticechk = noticeRepository.findById(noticeId);
        if (noticechk.isPresent()) {
            Notice notice = noticechk.get();
            NoticeResponse noticeResponse = NoticeResponse.builder()
                    .noticeId(notice.getNoticeId())
                    .heading(notice.getHeading())
                    .content(notice.getContent())
                    .datePosted(notice.getDatePosted()) // Assuming it's a String as per  entity
                    .noticeImage(notice.getNoticeImage())
                    .societyId(notice.getSocietyProfile().getSocietyId())  // Extract societyId from SocietyProfile
                    .build();
            return ResponseEntity.status(HttpStatus.OK).body(noticeResponse);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("NoticeId " + noticeId + " Not found");
        }


    }

    public ResponseEntity<?> UpdateNotice(Long noticeId, NoticeResponse noticeupd) {
        Optional<Notice> noticechk = noticeRepository.findById(noticeId);
        if (noticechk.isPresent()) {
            Optional<SocietyProfile> schk = societyRepo.findById(noticeupd.getSocietyId());
            if (schk.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("SocietyId " + noticeupd.getSocietyId() + " Not found");
            }
            Notice notice = noticechk.get();
            notice.setHeading(noticeupd.getHeading());
            notice.setContent(noticeupd.getContent());
            notice.setNoticeImage(noticeupd.getNoticeImage());
            notice.setSocietyProfile(schk.get());

            var saved = noticeRepository.save(notice);

            NoticeResponse noticeResponse = NoticeResponse.builder().noticeImage(saved.getNoticeImage())
                    .heading(saved.getHeading()).content(saved.getContent()).datePosted(saved.getDatePosted())
                    .noticeId(saved.getNoticeId()).societyId(saved.getSocietyProfile().getSocietyId()).build();

            return ResponseEntity.status(HttpStatus.OK).body(noticeResponse);

        } else {
            return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("NoticeId " + noticeId + " Not found");
        }

    }

    public ResponseEntity<?> GetAllNotices() {
        List<Object[]> results = noticeRepository.getAllNotices();
        List<NoticeResponse> responseList = new ArrayList<>();
        for (Object[] result : results) {
            NoticeResponse response = new NoticeResponse(
                    (Long) result[0],
                    (String) result[1],
                    (String) result[2],
                    (String) result[3],
                    (String) result[4],
                    (Long) result[5]
            );
            responseList.add(response);
        }
        return ResponseEntity.ok(responseList);
    }

  public ResponseEntity<?> PatchupdateNotice(Long noticeId, Map<String,Object> updates){
        Optional<Notice> noticechk = noticeRepository.findById(noticeId);
        if(noticechk.isPresent()){
            Notice noticeupd = noticechk.get();
            if (updates.containsKey("heading")) {
                noticeupd.setContent((String) updates.get("heading"));

            }
            if(updates.containsKey("content")){
                noticeupd.setContent((String) updates.get("content"));
            }
            if(updates.containsKey("datePosted")){
                noticeupd.setDatePosted((String) updates.get("datePosted"));
            }
            if(updates.containsKey("noticeImage")){
                noticeupd.setNoticeImage((String) updates.get("noticeImage"));
            }
            if(updates.containsKey("societyId")){
                Optional<SocietyProfile> societyProfilechk=societyRepo.findById(Long.parseLong((String) updates.get("societyId")));
                if(societyProfilechk.isPresent()) {
                    noticeupd.setSocietyProfile(societyProfilechk.get());
                }else{
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("The given SocietyId "+updates.get("societyId")+" Not found");
                }
            }

              var saved=noticeRepository.save(noticeupd);
               NoticeResponse noticeResponse=NoticeResponse.builder().noticeId(saved.getNoticeId())
                       .heading(saved.getHeading()).content(saved.getContent())
                       .noticeImage(saved.getNoticeImage()).datePosted(saved.getDatePosted())
                       .societyId(saved.getSocietyProfile().getSocietyId()).build();

            return ResponseEntity.ok(noticeResponse);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("NoticeId " + noticeId + " Not found");
        }


  }
}
