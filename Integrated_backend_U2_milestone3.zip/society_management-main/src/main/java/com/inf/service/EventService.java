package com.inf.service;

import com.inf.dto.EventAddResponse;
import com.inf.dto.EventaddRequest;
import com.inf.model.Event;
import com.inf.model.SocietyProfile;
import com.inf.repository.EventRespository;
import com.inf.repository.FeedbackRepository;
import com.inf.repository.SocietyRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EventService {
    private final EventRespository eventRespository;
    private final SocietyRepo societyRepository;
    private final FeedbackRepository feedbackRepository;

    public ResponseEntity<?> addEvent(long societyId, @RequestBody EventaddRequest eventaddRequest) {
        Optional<SocietyProfile> society = societyRepository.findById(societyId);
        if (society.isPresent()) {
            Event evechk = eventRespository.findByEventName(eventaddRequest.getEventName());
            if (evechk == null) {
                Long maxeveid = eventRespository.maxEveId();
                if (maxeveid == null) {
                    eventRespository.setAutoIncrement(1L);
                } else {

                    eventRespository.setAutoIncrement(maxeveid + 1);
                }
                Event event = Event.builder().eventName(eventaddRequest.getEventName())
                        .eventDate(eventaddRequest.getEventDate()).eventImage(eventaddRequest.getEventImage())
                        .eventDetails(eventaddRequest.getEventDetails()).society(society.get()).build();
                eventRespository.save(event);
                //finding by eventname to fetch society id
                Event foundEvent = eventRespository.findByEventName(event.getEventName());
                //final responsebody of event
                EventAddResponse eveResp = EventAddResponse.builder().eventId(foundEvent.getEventId())
                        .eventName(foundEvent.getEventName()).eventImage(foundEvent.getEventImage())
                        .eventDate(foundEvent.getEventDate())
                        .eventDetails(foundEvent.getEventDetails()).SocietyId(foundEvent.getSociety().getSocietyId()).build();

                return ResponseEntity.status(HttpStatus.CREATED).body(eveResp);
            } else {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("The Event " + "'" +
                        eventaddRequest.getEventName() + "'" + " is already Registered");
            }

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("society id " + societyId + " not found");
        }

    }

    public List<EventAddResponse> getAllEvents() {
        List<Object[]> results = eventRespository.findAllEvents();
        List<EventAddResponse> responseList = new ArrayList<>();

        for (Object[] result : results) {
            EventAddResponse response = new EventAddResponse(
                    (Long) result[0],
                    (String) result[1],
                    (String) result[2],
                    (String) result[3],
                    (String) result[4],
                    (Long) result[5]

            );
            responseList.add(response);
        }

        return responseList;


    }

    public ResponseEntity<?> updateEvent(Long eventId, @RequestBody Map<String, Object> updates) {
        Optional<Event> evechk = eventRespository.findById(eventId);

        if (evechk.isPresent()) {
            Event updatedEvent = evechk.get();
            if (updates.containsKey("eventName")) {
                updatedEvent.setEventName((String) updates.get("eventName"));
            }
            if (updates.containsKey("eventDate")) {
                updatedEvent.setEventDate((String) updates.get("eventDate"));
            }
            if (updates.containsKey("eventImage")) {
                updatedEvent.setEventImage((String) updates.get("eventImage"));

            }
            if (updates.containsKey("eventDetails")) {
                updatedEvent.setEventDetails((String) updates.get("eventDetails"));
            }
            if (updates.containsKey("societyId")) {
                Optional<SocietyProfile> society = societyRepository.findById(Long.parseLong((String) updates.get("societyId")));
                if (society.isPresent()) {
                    updatedEvent.setSociety(society.get());
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("The given society id " + updates.get("societyId") + " not found");
                }

            }
            var saved=eventRespository.save(updatedEvent);
            EventAddResponse finalResponse = EventAddResponse.builder().eventId(saved.getEventId())
                    .eventName(saved.getEventName()).eventDate(saved.getEventDate())
                    .eventDetails(saved.getEventDetails()).eventImage(saved.getEventImage())
                    .SocietyId(saved.getSociety().getSocietyId()).build();

            return ResponseEntity.status(HttpStatus.OK).body(finalResponse);

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Event id " + eventId + " not found");
        }


    }

    public ResponseEntity<?> deleteEvent(Long eventId) {
        Optional<Event> evechk = eventRespository.findById(eventId);
        if(evechk.isPresent()) {
            feedbackRepository.deleteAllfeedbackByEventId(evechk.get().getEventId());
            eventRespository.delete(evechk.get());


            return ResponseEntity.status(HttpStatus.OK).body("Event Id " + eventId + " successfully deleted");
        }
        else{
            return  ResponseEntity.status(HttpStatus.NOT_FOUND).body("Event id " + eventId + " not found");

        }
    }


}
