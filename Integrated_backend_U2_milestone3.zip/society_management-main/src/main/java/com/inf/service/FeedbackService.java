package com.inf.service;

import com.inf.dto.FeedbackAddreq;
import com.inf.dto.FeedbackReponse;
import com.inf.model.Event;
import com.inf.model.Feedback;
import com.inf.repository.EventRespository;
import com.inf.repository.FeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FeedbackService {
    private final FeedbackRepository feedbackRepository;
    private final EventRespository eventRespository;


    public ResponseEntity<?> addFeedback(Long eventId, FeedbackAddreq feedbackAddreq) {
        Optional<Event> evechk = eventRespository.findById(eventId);
        if (evechk.isPresent()) {
            Long maxfbid=feedbackRepository.maxID();
            if(maxfbid!=null){
                feedbackRepository.SetAutoincrement(maxfbid+1);
            }
            else{
                feedbackRepository.SetAutoincrement(1L);
            }
            Feedback feedback = Feedback.builder().content(feedbackAddreq.getContent())
                    .event(evechk.get()).build();
            var saved = feedbackRepository.save(feedback);
            FeedbackReponse fresponse = FeedbackReponse.builder().feedbackId(saved.getFeedbackId())
                    .content(saved.getContent()).eventId(saved.getEvent().getEventId()).build();
            return ResponseEntity.ok(fresponse);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("EventID " + eventId + " not found");
        }


    }

    public ResponseEntity<?> updateFeedback(Long feedbackId, Map<String, Object> updates) {

        Optional<Feedback> fchk = feedbackRepository.findById(feedbackId);
        if (fchk.isPresent()) {
            Feedback updatedFb = fchk.get();
            if (updates.containsKey("content")) {
                updatedFb.setContent((String) updates.get("content"));

            }
            if (updates.containsKey("eventId")) {
                Optional<Event> evechk = eventRespository.findById(Long.parseLong((String) updates.get("eventId")));
                if (evechk.isPresent()) {
                    updatedFb.setEvent(evechk.get());

                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("EventID " + updates.get("eventId") + " not found");
                }


            }
            feedbackRepository.save(updatedFb);
            FeedbackReponse fresp = FeedbackReponse.builder()
                    .feedbackId(updatedFb.getFeedbackId()).content(updatedFb.getContent())
                    .eventId(updatedFb.getEvent().getEventId()).build();
            return ResponseEntity.ok(fresp);

        } else {

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("FeedbackID " + feedbackId + " not found");
        }


    }

    public ResponseEntity<?> deleteByfbid(Long fbid) {
        Optional<Feedback> fchk = feedbackRepository.findById(fbid);
        if (fchk.isPresent()) {
            feedbackRepository.delete(fchk.get());
            return ResponseEntity.status(HttpStatus.OK).body("FeedbackID " + fbid + " deleted successfully");
        }
        else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("FeedbackID " + fbid + " not found");
        }
    }

    public ResponseEntity<?> getAllFeedback() {
        List<Object[]> results=feedbackRepository.getAllFeedbacks();
        List<FeedbackReponse> responseList=new ArrayList<>();
        for(Object[] result:results){
            FeedbackReponse response=new FeedbackReponse(
                    (Long) result[0],
                    (String) result[1],
                    (Long) result[2]
            );
            responseList.add(response);
        }
        return ResponseEntity.ok(responseList);
    }


}
