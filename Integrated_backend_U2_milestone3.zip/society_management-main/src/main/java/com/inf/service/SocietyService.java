package com.inf.service;

import com.inf.dto.SocietyDetailResponse;
import com.inf.dto.SocietyProfiledto;
import com.inf.model.SocietyProfile;
import com.inf.model.User;
import com.inf.repository.SocietyRepo;
import com.inf.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class SocietyService {

    @Autowired
    private SocietyRepo societyRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;


    // Read All
    public List<SocietyDetailResponse> getAllsocietyDetails() {
        List<Object[]> results = societyRepository.findAllsocietydetails();
        List<SocietyDetailResponse> responseList = new ArrayList<>();

        for (Object[] result : results) {
            SocietyDetailResponse response = new SocietyDetailResponse(
                    (Long) result[0], // residentId
                    (String) result[1], // name
                    (String) result[2], // phoneNo
                    (String) result[3], // flatNo
                    (String) result[4], // postal
                    (String) result[5], // email
                    (String) result[6], // flatId
                    (String) result[7],
                    (String) result[8],
                    (Long) result[9]
                    // societyId
            );
            responseList.add(response);
        }
        return responseList;
    }

    // Read by ID
    public ResponseEntity<?> getSocietyById(Long id) {
        Optional<SocietyProfile> society = societyRepository.findById(id);
        if (society.isPresent()) {
            SocietyProfile s = society.get();
            var response = SocietyDetailResponse.builder()
                    .societyId(s.getSocietyId()).societyAddress(s.getSocietyAddress()).name(s.getName())
                    .societyName(s.getSocietyName()).postal(s.getPostal()).User(s.getUser().getId())
                    .city(s.getCity()).email(s.getEmail()).district(s.getDistrict())
                    .phoneNo(s.getPhoneNo()).build();
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("societyId " + id + " Not Found");
        }


    }

    // Update
    public ResponseEntity<?> updateSociety(Long id, SocietyDetailResponse societyDto) {
        Optional<SocietyProfile> society = societyRepository.findById(id);

        if (society.isPresent()) {
            SocietyProfile s = society.get();
            Optional<User> user = userRepository.findById(societyDto.getUser());
            if (user.isPresent()) {
                s.setUser(user.get());
                var user1 = user.get();
                user1.setUsername(societyDto.getEmail());
                userRepository.save(user1);

            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("user Id " + societyDto.getUser() + " You Entered is Not Found \n Ask the User to Register First ");
            }

            s.setName(societyDto.getName());
            s.setPostal(societyDto.getPostal());
            s.setSocietyAddress(societyDto.getSocietyAddress());
            s.setSocietyName(societyDto.getSocietyName());
            s.setDistrict(societyDto.getDistrict());
            s.setUser(society.get().getUser());
            s.setCity(societyDto.getCity());
            s.setEmail(societyDto.getEmail());
            s.setPhoneNo(societyDto.getPhoneNo());

            societyRepository.save(s);
            SocietyDetailResponse response = SocietyDetailResponse.builder()
                    .societyId(s.getSocietyId()).societyAddress(s.getSocietyAddress()).name(s.getName())
                    .societyName(s.getSocietyName()).postal(s.getPostal()).User(s.getUser().getId())
                    .city(s.getCity()).email(s.getEmail()).district(s.getDistrict())
                    .phoneNo(s.getPhoneNo()).build();

            return ResponseEntity.status(HttpStatus.OK).body(response);

        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Society Id " + id + " not found");
        }

    }

    // Delete

    public ResponseEntity<String> patchupdateSocietyById(long Id, Map<String, Object> updates) {
        Optional<SocietyProfile> society = societyRepository.findById(Id);
        if (society.isPresent()) {
            SocietyProfile updsoc = society.get();
            if (updates.containsKey("name")) {
                updsoc.setName((String) updates.get("name"));
            }
            if (updates.containsKey("phoneNo")) {
                updsoc.setPhoneNo((String) updates.get("phoneNo"));
            }
            if (updates.containsKey("societyName")) {
                updsoc.setSocietyName((String) updates.get("societyName"));
            }
            if (updates.containsKey("societyAddress")) {
                updsoc.setSocietyAddress((String) updates.get("societyAddress"));
            }
            if (updates.containsKey("city")) {
                updsoc.setCity((String) updates.get("city"));
            }
            if (updates.containsKey("district")) {
                updsoc.setDistrict((String) updates.get("district"));
            }
            if (updates.containsKey("postal")) {
                updsoc.setPostal((String) updates.get("postal"));
            }
            if (updates.containsKey("email")) {
                Optional<User> userchk = userRepository.findById(updsoc.getUser().getId());
                if (userchk.isPresent()) {
                    User user = userchk.get();
                    user.setUsername((String) updates.get("email"));
                    userRepository.save(user);
                    updsoc.setEmail(userchk.get().getUsername());
                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ExistingUserId Id not found for updating email");
                }
            }
            if (updates.containsKey("password")) {
                Optional<User> userchk = userRepository.findById(updsoc.getUser().getId());
                if (userchk.isPresent()) {
                    User user = userchk.get();
                    user.setPassword(passwordEncoder.encode((String) updates.get("password")));
                    userRepository.save(user);

                } else {
                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Existing User Id not found updating password");
                }
            }
            if (updates.containsKey("role")) {

                Optional<User> userchk = userRepository.findById(updsoc.getUser().getId());
                if (userchk.isPresent()) {
                    User user = userchk.get();

                    user.setRole((String) updates.get("role"));
                    userRepository.save(user);

                } else {

                    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Existing User Id not found for updating role");
                }


            }
            societyRepository.save(updsoc);
            return ResponseEntity.status(HttpStatus.OK).body("Society updated Successfully");


        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Society Id Not Found");
        }



    }

    public ResponseEntity<?> DeleteById(long id){
        Optional<SocietyProfile> socchk=societyRepository.findById(id);

        if(socchk.isPresent()){
            User userdel=socchk.get().getUser();
            societyRepository.delete(socchk.get());
            userRepository.delete(userdel);
            return ResponseEntity.status(HttpStatus.OK).body("Society Deleted Successfully");
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Society Id "+id+" Not Found");
        }


    }

}
