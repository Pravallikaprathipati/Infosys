package com.inf.repository;
import com.inf.model.Notice;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NoticeRepository extends JpaRepository<Notice,Long> {


    // Native query to find the maximum noticeId
    @Query(value = "SELECT MAX(notice_id) FROM notice", nativeQuery = true)
    Long findMaxNoticeId();

    // Native query to set the AUTO_INCREMENT value for flat_id
    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE notice AUTO_INCREMENT = :newValue", nativeQuery = true)
    void setAutoIncrement(@Param("newValue") Long newValue);

    @Query(value = "SELECT n.noticeId AS noticeId,n.heading AS heading,n.content AS content, "
            +"n.datePosted AS datePosted,n.noticeImage AS noticeImage, n.societyProfile.societyId AS societyId "+
            "FROM Notice n")
    List<Object[]> getAllNotices();
}
