package com.inf.repository;

import com.inf.model.SocietyProfile;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SocietyRepo extends JpaRepository<SocietyProfile,Long> {
    @Query("SELECT s.societyId AS SocietyId, s.name AS name, s.phoneNo AS phoneNo, s.societyName AS SocietyName," +
            "s.societyAddress AS societyAdress, s.city AS City, s.district AS District, s.postal AS Postal, s.email AS Email,s.user " +
            "FROM SocietyProfile s")
    List<Object[]> findAllsocietydetails();

    @Query("SELECT MAX(s.societyId) from SocietyProfile s")
    Long findMaxSocietyId();

    // Method to set the AUTO_INCREMENT value
    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE society AUTO_INCREMENT = :newValue", nativeQuery = true)
    void setAutoIncrement(@Param("newValue") Long newValue);

    @Query(value = "SELECT * FROM society_profile s WHERE s.society_name = :societyName LIMIT 1", nativeQuery = true)
    SocietyProfile findFirstBySocietyName(@Param("societyName") String societyName);



    SocietyProfile findBySocietyNameAndSocietyAddressAndPhoneNo(String societyName, String societyAddress, String phoneNo);
}
