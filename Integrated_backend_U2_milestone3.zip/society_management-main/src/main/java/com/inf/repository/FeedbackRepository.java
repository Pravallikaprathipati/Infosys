package com.inf.repository;

import com.inf.model.Feedback;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
    @Modifying
    @Transactional
    @Query( value = "DELETE FROM feedback f WHERE f.event_id =:newvalue",nativeQuery = true )
    void deleteAllfeedbackByEventId(@Param("newvalue") Long eventId);

    @Query(value = "SELECT MAX(f.feedbackId) FROM Feedback f")
    Long maxID();

    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE feedback AUTO_INCREMENT =:newvalue",nativeQuery = true)
    void SetAutoincrement(@Param("newvalue") Long feedbackId);

    @Query(value = "SELECT f.feedbackId AS feedbackId,f.content AS content,f.event.eventId FROM Feedback f")
    List<Object[]> getAllFeedbacks();

}
