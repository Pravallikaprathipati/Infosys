package com.inf.repository;

import com.inf.model.Flat;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FlatRepository extends JpaRepository<Flat,Long> {

    Flat findBySocietyProfileSocietyId(long societyId);

    // Native query to find the maximum flat_id
    @Query(value = "SELECT MAX(flat_id) FROM flat", nativeQuery = true)
    Long findMaxFlatId();

    // Native query to set the AUTO_INCREMENT value for flat_id
    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE flat AUTO_INCREMENT = :newValue", nativeQuery = true)
    void setAutoIncrement(@Param("newValue") Long newValue);

    Flat findByFlatNo(String flatno);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM flat WHERE society_id= :newvalue", nativeQuery = true)
    void deletebysocietyid(@Param("newvalue") long Id);

}
