package com.inf.repository;

import com.inf.model.Event;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface EventRespository extends JpaRepository<Event, Long> {
    @Query(value="SELECT MAX(eventId) FROM Event")
    Long maxEveId();

    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE event AUTO_INCREMENT = :newValue", nativeQuery = true)
    void setAutoIncrement(@Param("newValue") Long newValue);

    @Query(value = "SELECT * FROM event e WHERE e.event_name = :newvalue", nativeQuery = true)
    Event findByEventName(@Param("newvalue") String eventname);

    @Query("SELECT e.eventId AS eventId, e.eventName AS eventName, e.eventDate AS eventDate, e.eventDetails AS eventDetails," +
            "e.eventImage AS eventImage, e.society.societyId AS societyId " +
            "FROM Event e")
    List<Object[]> findAllEvents();
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM event WHERE society_id = :newValue", nativeQuery = true)
    void deleteBySocietyId(@Param("newValue") Long societyId);
}
