package com.inf.repository;

import com.inf.model.ResidentProfile;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ResidentProfileRepository extends JpaRepository<ResidentProfile, Long> {

    @Query(value = "SELECT MAX(residentid) FROM resident_profiles", nativeQuery = true)
    Long findMaxResidentId();

    // Native query to set the AUTO_INCREMENT value for resident_id
    @Modifying
    @Transactional
    @Query(value = "ALTER TABLE resident AUTO_INCREMENT = :newValue", nativeQuery = true)
    void setAutoIncrement(@Param("newValue") Long newValue);

    @Query("SELECT r.residentid AS residentid, r.name AS name, r.phoneNo AS phoneNo, r.flatNo AS flatNo, " +
            "r.postal AS postal, r.email AS email, r.flat.flatId AS flatId, r.societyProfile.societyId AS societyId,r.user.id AS user_id " +
            "FROM ResidentProfile r")
    List<Object[]> findAllResidentDetails();
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM resident_profiles WHERE society_id = :newValue", nativeQuery = true)
    void deletebySocietyId(@Param("newValue") Long societyId);
}
